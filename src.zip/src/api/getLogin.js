import request from '@/utils/request.js'

// 登录
export const login = (data) => {
	return request({
		url: '/login/accountLogin',//请求接口
		method: 'post',//请求方式
		data//请求参数
	})
}

//注册
export const register = (data) => {
	return request({
		url: '/login/register',//请求接口
		method: 'post',//请求方式
		data//请求参数
	})
}

//退出登录
export const logout = (data) => {
	return request({
		url: '/login/logout',//请求接口
		method: 'get',//请求方式
		data//请求参数
	})
}
