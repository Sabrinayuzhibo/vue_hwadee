<template>
  <div class="footer">
    @ 后台管理系统
  </div>
</template>

<style scoped>
.footer {
  padding: 20px;
  text-align: center;
  color: #909399;
  font-size: 14px;
  border-top: 1px solid #ebeef5;
}
</style>
