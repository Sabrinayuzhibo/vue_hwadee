<template>
  <div class="course-replacement">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>课程顶替管理</span>
          <el-button type="primary" @click="showRuleDialog = true">
            <el-icon><Plus /></el-icon>
            新增顶替规则
          </el-button>
        </div>
      </template>
      
      <el-table :data="replacementList" stripe style="width: 100%">
        <el-table-column prop="oldCourseCode" label="原课程代码" width="120" />
        <el-table-column prop="oldCourseName" label="原课程名称" width="150" />
        <el-table-column prop="newCourseCode" label="新课程代码" width="120" />
        <el-table-column prop="newCourseName" label="新课程名称" width="150" />
        <el-table-column prop="major" label="适用专业" width="150" />
        <el-table-column prop="validDate" label="有效期" width="120" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="scope">
            <el-tag :type="scope.row.status === 'active' ? 'success' : 'info'">
              {{ scope.row.status === 'active' ? '有效' : '失效' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template #default="scope">
            <el-button size="small" @click="editRule(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteRule(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 顶替规则对话框 -->
    <el-dialog v-model="showRuleDialog" title="顶替规则配置" width="600px">
      <el-form :model="ruleForm" label-width="120px">
        <el-form-item label="原课程">
          <el-select v-model="ruleForm.oldCourseCode" placeholder="请选择原课程">
            <el-option label="大学语文（专）" value="001" />
            <el-option label="高等数学（专）" value="002" />
          </el-select>
        </el-form-item>
        <el-form-item label="新课程">
          <el-select v-model="ruleForm.newCourseCode" placeholder="请选择新课程">
            <el-option label="应用文写作" value="101" />
            <el-option label="高等数学" value="102" />
          </el-select>
        </el-form-item>
        <el-form-item label="适用专业">
          <el-select v-model="ruleForm.major" placeholder="请选择专业">
            <el-option label="计算机科学与技术" value="计算机科学与技术" />
            <el-option label="汉语言文学" value="汉语言文学" />
          </el-select>
        </el-form-item>
        <el-form-item label="有效期">
          <el-date-picker v-model="ruleForm.validDate" type="date" placeholder="选择有效期" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showRuleDialog = false">取消</el-button>
          <el-button type="primary" @click="saveRule">保存</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'

const showRuleDialog = ref(false)
const replacementList = ref([
  {
    oldCourseCode: '001',
    oldCourseName: '大学语文（专）',
    newCourseCode: '101',
    newCourseName: '应用文写作',
    major: '汉语言文学',
    validDate: '2024-12-31',
    status: 'active'
  }
])

const ruleForm = reactive({
  oldCourseCode: '',
  newCourseCode: '',
  major: '',
  validDate: ''
})

const editRule = (row) => {
  ElMessage.info(`编辑规则: ${row.oldCourseName} -> ${row.newCourseName}`)
}

const deleteRule = (row) => {
  ElMessage.success(`删除规则: ${row.oldCourseName} -> ${row.newCourseName}`)
}

const saveRule = () => {
  ElMessage.success('规则保存成功')
  showRuleDialog.value = false
}
</script>

<style scoped>
.course-replacement {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 