<template>
  <div class="exemption-management">
    <!-- 功能操作栏 -->
    <div class="operation-bar">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-button type="primary" @click="showPolicyDialog = true">
            <el-icon><Setting /></el-icon>
            政策配置
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="success" @click="showApplyDialog = true">
            <el-icon><Plus /></el-icon>
            免考申请
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="warning" @click="showAuditDialog = true">
            <el-icon><Search /></el-icon>
            审核管理
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="info" @click="exportExemptionList">
            <el-icon><Download /></el-icon>
            导出名单
          </el-button>
        </el-col>
      </el-row>
    </div>

    <!-- 搜索条件 -->
    <el-card class="search-card">
      <el-form :inline="true" :model="searchForm" class="search-form">
        <el-form-item label="考生姓名">
          <el-input v-model="searchForm.studentName" placeholder="请输入考生姓名" clearable />
        </el-form-item>
        <el-form-item label="考籍号">
          <el-input v-model="searchForm.studentId" placeholder="请输入考籍号" clearable />
        </el-form-item>
        <el-form-item label="申请状态">
          <el-select v-model="searchForm.status" placeholder="请选择状态" clearable>
            <el-option label="待审核" value="pending" />
            <el-option label="初审通过" value="first_approved" />
            <el-option label="终审通过" value="final_approved" />
            <el-option label="已驳回" value="rejected" />
          </el-select>
        </el-form-item>
        <el-form-item label="申请时间">
          <el-date-picker
            v-model="searchForm.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="searchExemptions">查询</el-button>
          <el-button @click="resetSearch">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 免考申请列表 -->
    <el-card class="table-card">
      <template #header>
        <div class="card-header">
          <span>免考申请列表</span>
          <div class="header-actions">
            <el-tag type="info">待审核: {{ pendingCount }}</el-tag>
            <el-tag type="success">已通过: {{ approvedCount }}</el-tag>
            <el-tag type="danger">已驳回: {{ rejectedCount }}</el-tag>
          </div>
        </div>
      </template>

      <el-table :data="exemptionList" stripe style="width: 100%" v-loading="loading">
        <el-table-column prop="studentId" label="考籍号" width="120" />
        <el-table-column prop="studentName" label="考生姓名" width="100" />
        <el-table-column prop="major" label="专业" width="150" />
        <el-table-column prop="courseCode" label="课程代码" width="100" />
        <el-table-column prop="courseName" label="课程名称" width="150" />
        <el-table-column prop="exemptionType" label="免考类型" width="120">
          <template #default="scope">
            <el-tag :type="getExemptionTypeTag(scope.row.exemptionType)">
              {{ scope.row.exemptionType }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="applyDate" label="申请时间" width="120" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ getStatusText(scope.row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="auditor" label="审核人" width="100" />
        <el-table-column prop="auditDate" label="审核时间" width="120" />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="viewDetail(scope.row)">查看</el-button>
            <el-button 
              size="small" 
              type="primary" 
              @click="auditExemption(scope.row)"
              v-if="scope.row.status === 'pending'"
            >
              审核
            </el-button>
            <el-button size="small" type="warning" @click="downloadMaterials(scope.row)">
              材料
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 免考政策配置对话框 -->
    <el-dialog v-model="showPolicyDialog" title="免考政策配置" width="800px">
      <el-tabs v-model="activeTab">
        <el-tab-pane label="政策列表" name="policy-list">
          <div class="policy-actions">
            <el-button type="primary" @click="showAddPolicyDialog = true">
              <el-icon><Plus /></el-icon>
              新增政策
            </el-button>
          </div>
          <el-table :data="policyList" stripe style="width: 100%">
            <el-table-column prop="policyName" label="政策名称" />
            <el-table-column prop="courseCode" label="课程代码" width="100" />
            <el-table-column prop="courseName" label="课程名称" />
            <el-table-column prop="exemptionCondition" label="免考条件" />
            <el-table-column prop="status" label="状态" width="80">
              <template #default="scope">
                <el-tag :type="scope.row.status === 'active' ? 'success' : 'info'">
                  {{ scope.row.status === 'active' ? '启用' : '停用' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button size="small" @click="editPolicy(scope.row)">编辑</el-button>
                <el-button 
                  size="small" 
                  :type="scope.row.status === 'active' ? 'warning' : 'success'"
                  @click="togglePolicyStatus(scope.row)"
                >
                  {{ scope.row.status === 'active' ? '停用' : '启用' }}
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="政策统计" name="policy-stats">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-card>
                <template #header>政策使用统计</template>
                <div class="chart-container">
                  <div class="chart-placeholder">政策使用统计图表</div>
                </div>
              </el-card>
            </el-col>
            <el-col :span="12">
              <el-card>
                <template #header>免考通过率</template>
                <div class="chart-container">
                  <div class="chart-placeholder">免考通过率图表</div>
                </div>
              </el-card>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>

    <!-- 免考申请对话框 -->
    <el-dialog v-model="showApplyDialog" title="免考申请" width="700px">
      <el-form :model="applyForm" :rules="applyRules" ref="applyFormRef" label-width="120px">
        <el-form-item label="考生信息">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-input v-model="applyForm.studentId" placeholder="请输入考籍号" />
            </el-col>
            <el-col :span="12">
              <el-button @click="searchStudent">查询考生</el-button>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="考生姓名" prop="studentName">
          <el-input v-model="applyForm.studentName" disabled />
        </el-form-item>
        <el-form-item label="报考专业" prop="major">
          <el-input v-model="applyForm.major" disabled />
        </el-form-item>
        <el-form-item label="免考课程" prop="courseCode">
          <el-select v-model="applyForm.courseCode" placeholder="请选择课程" @change="onCourseChange">
            <el-option 
              v-for="course in availableCourses" 
              :key="course.code" 
              :label="`${course.code} - ${course.name}`" 
              :value="course.code" 
            />
          </el-select>
        </el-form-item>
        <el-form-item label="免考类型" prop="exemptionType">
          <el-select v-model="applyForm.exemptionType" placeholder="请选择免考类型">
            <el-option label="全国计算机等级考试" value="计算机等级考试" />
            <el-option label="英语等级考试" value="英语等级考试" />
            <el-option label="职业资格证书" value="职业资格证书" />
            <el-option label="其他学历课程" value="其他学历课程" />
          </el-select>
        </el-form-item>
        <el-form-item label="证明材料" prop="materials">
          <el-upload
            action="#"
            list-type="picture-card"
            :auto-upload="false"
            :on-change="handleMaterialChange"
            multiple
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
          <div class="upload-tip">请上传成绩单、证书等证明材料扫描件</div>
        </el-form-item>
        <el-form-item label="申请说明" prop="description">
          <el-input 
            v-model="applyForm.description" 
            type="textarea" 
            :rows="3"
            placeholder="请详细说明免考理由和相关情况"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showApplyDialog = false">取消</el-button>
          <el-button type="primary" @click="submitExemption">提交申请</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 审核对话框 -->
    <el-dialog v-model="showAuditDialog" title="免考审核" width="600px">
      <el-form :model="auditForm" :rules="auditRules" ref="auditFormRef" label-width="100px">
        <el-form-item label="审核结果" prop="result">
          <el-radio-group v-model="auditForm.result">
            <el-radio label="approve">通过</el-radio>
            <el-radio label="reject">驳回</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="审核意见" prop="comment">
          <el-input 
            v-model="auditForm.comment" 
            type="textarea" 
            :rows="4"
            placeholder="请填写审核意见"
          />
        </el-form-item>
        <el-form-item label="审核级别" prop="level">
          <el-select v-model="auditForm.level" placeholder="请选择审核级别">
            <el-option label="市州初审" value="city" />
            <el-option label="省考试院终审" value="province" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showAuditDialog = false">取消</el-button>
          <el-button type="primary" @click="submitAudit">提交审核</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  Setting, 
  Plus, 
  Search, 
  Download,
  Edit,
  Delete
} from '@element-plus/icons-vue'

// 响应式数据
const loading = ref(false)
const showPolicyDialog = ref(false)
const showApplyDialog = ref(false)
const showAuditDialog = ref(false)
const showAddPolicyDialog = ref(false)
const activeTab = ref('policy-list')
const currentPage = ref(1)
const pageSize = ref(20)
const total = ref(0)
const pendingCount = ref(0)
const approvedCount = ref(0)
const rejectedCount = ref(0)

// 搜索表单
const searchForm = reactive({
  studentName: '',
  studentId: '',
  status: '',
  dateRange: []
})

// 申请表单
const applyForm = reactive({
  studentId: '',
  studentName: '',
  major: '',
  courseCode: '',
  courseName: '',
  exemptionType: '',
  materials: [],
  description: ''
})

// 审核表单
const auditForm = reactive({
  result: '',
  comment: '',
  level: ''
})

// 表单验证规则
const applyRules = {
  courseCode: [
    { required: true, message: '请选择免考课程', trigger: 'change' }
  ],
  exemptionType: [
    { required: true, message: '请选择免考类型', trigger: 'change' }
  ],
  description: [
    { required: true, message: '请填写申请说明', trigger: 'blur' }
  ]
}

const auditRules = {
  result: [
    { required: true, message: '请选择审核结果', trigger: 'change' }
  ],
  comment: [
    { required: true, message: '请填写审核意见', trigger: 'blur' }
  ],
  level: [
    { required: true, message: '请选择审核级别', trigger: 'change' }
  ]
}

// 可用课程列表
const availableCourses = ref([
  { code: '001', name: '计算机应用基础' },
  { code: '002', name: '大学英语' },
  { code: '003', name: '高等数学' },
  { code: '004', name: '马克思主义基本原理' }
])

// 政策列表
const policyList = ref([
  {
    policyName: '全国计算机等级考试二级免考政策',
    courseCode: '001',
    courseName: '计算机应用基础',
    exemptionCondition: '全国计算机等级考试二级及以上证书',
    status: 'active'
  },
  {
    policyName: '英语等级考试免考政策',
    courseCode: '002',
    courseName: '大学英语',
    exemptionCondition: 'CET-4及以上证书',
    status: 'active'
  }
])

// 免考申请列表
const exemptionList = ref([
  {
    studentId: '2024001',
    studentName: '张三',
    major: '计算机科学与技术',
    courseCode: '001',
    courseName: '计算机应用基础',
    exemptionType: '计算机等级考试',
    applyDate: '2024-01-15',
    status: 'pending',
    auditor: '',
    auditDate: ''
  },
  {
    studentId: '2024002',
    studentName: '李四',
    major: '汉语言文学',
    courseCode: '002',
    courseName: '大学英语',
    exemptionType: '英语等级考试',
    applyDate: '2024-01-10',
    status: 'final_approved',
    auditor: '王审核',
    auditDate: '2024-01-12'
  }
])

// 获取免考类型标签
const getExemptionTypeTag = (type) => {
  const tags = {
    '计算机等级考试': 'primary',
    '英语等级考试': 'success',
    '职业资格证书': 'warning',
    '其他学历课程': 'info'
  }
  return tags[type] || 'info'
}

// 获取状态类型
const getStatusType = (status) => {
  const types = {
    pending: 'warning',
    first_approved: 'info',
    final_approved: 'success',
    rejected: 'danger'
  }
  return types[status] || 'info'
}

// 获取状态文本
const getStatusText = (status) => {
  const texts = {
    pending: '待审核',
    first_approved: '初审通过',
    final_approved: '终审通过',
    rejected: '已驳回'
  }
  return texts[status] || '未知'
}

// 搜索免考申请
const searchExemptions = () => {
  loading.value = true
  setTimeout(() => {
    loading.value = false
    ElMessage.success('搜索完成')
  }, 1000)
}

// 重置搜索
const resetSearch = () => {
  Object.keys(searchForm).forEach(key => {
    searchForm[key] = ''
  })
}

// 查看详情
const viewDetail = (row) => {
  ElMessage.info(`查看免考申请详情: ${row.studentName}`)
}

// 审核免考申请
const auditExemption = (row) => {
  showAuditDialog.value = true
  ElMessage.info(`审核免考申请: ${row.studentName}`)
}

// 下载材料
const downloadMaterials = (row) => {
  ElMessage.success(`下载材料: ${row.studentName}`)
}

// 导出免考名单
const exportExemptionList = () => {
  ElMessage.success('免考名单导出成功')
}

// 搜索考生
const searchStudent = () => {
  // 模拟查询考生信息
  applyForm.studentName = '张三'
  applyForm.major = '计算机科学与技术'
}

// 课程选择变化
const onCourseChange = (courseCode) => {
  const course = availableCourses.value.find(c => c.code === courseCode)
  if (course) {
    applyForm.courseName = course.name
  }
}

// 材料上传处理
const handleMaterialChange = (file) => {
  console.log('上传材料:', file)
}

// 提交免考申请
const submitExemption = () => {
  ElMessage.success('免考申请提交成功')
  showApplyDialog.value = false
}

// 提交审核
const submitAudit = () => {
  ElMessage.success('审核提交成功')
  showAuditDialog.value = false
}

// 编辑政策
const editPolicy = (row) => {
  ElMessage.info(`编辑政策: ${row.policyName}`)
}

// 切换政策状态
const togglePolicyStatus = (row) => {
  const action = row.status === 'active' ? '停用' : '启用'
  ElMessageBox.confirm(`确定要${action}该政策吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    row.status = row.status === 'active' ? 'inactive' : 'active'
    ElMessage.success(`政策已${action}`)
  })
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
  searchExemptions()
}

const handleCurrentChange = (page) => {
  currentPage.value = page
  searchExemptions()
}

// 组件挂载时初始化数据
onMounted(() => {
  pendingCount.value = 15
  approvedCount.value = 85
  rejectedCount.value = 10
  total.value = exemptionList.value.length
})
</script>

<style scoped>
.exemption-management {
  padding: 20px;
}

.operation-bar {
  margin-bottom: 20px;
}

.search-card {
  margin-bottom: 20px;
}

.search-form {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.table-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

.policy-actions {
  margin-bottom: 20px;
}

.chart-container {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.chart-placeholder {
  color: #909399;
  font-size: 14px;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-form {
    flex-direction: column;
  }
  
  .card-header {
    flex-direction: column;
    gap: 10px;
  }
  
  .header-actions {
    justify-content: center;
  }
}
</style> 