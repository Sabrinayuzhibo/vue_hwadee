<template>
  <div class="graduation-management">
    <!-- 功能操作栏 -->
    <div class="operation-bar">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-button type="primary" @click="showApplyDialog = true">
            <el-icon><Plus /></el-icon>
            毕业申请
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="success" @click="showAuditDialog = true">
            <el-icon><Search /></el-icon>
            资格审核
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="warning" @click="showCertificateDialog = true">
            <el-icon><Document /></el-icon>
            证书管理
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="info" @click="exportGraduationList">
            <el-icon><Download /></el-icon>
            导出名单
          </el-button>
        </el-col>
      </el-row>
    </div>

    <!-- 搜索条件 -->
    <el-card class="search-card">
      <el-form :inline="true" :model="searchForm" class="search-form">
        <el-form-item label="考生姓名">
          <el-input v-model="searchForm.studentName" placeholder="请输入考生姓名" clearable />
        </el-form-item>
        <el-form-item label="考籍号">
          <el-input v-model="searchForm.studentId" placeholder="请输入考籍号" clearable />
        </el-form-item>
        <el-form-item label="申请批次">
          <el-select v-model="searchForm.batch" placeholder="请选择批次" clearable>
            <el-option label="2024年上半年" value="2024-1" />
            <el-option label="2024年下半年" value="2024-2" />
          </el-select>
        </el-form-item>
        <el-form-item label="申请状态">
          <el-select v-model="searchForm.status" placeholder="请选择状态" clearable>
            <el-option label="待审核" value="pending" />
            <el-option label="初审通过" value="first_approved" />
            <el-option label="终审通过" value="final_approved" />
            <el-option label="已发证" value="certified" />
            <el-option label="已驳回" value="rejected" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="searchGraduations">查询</el-button>
          <el-button @click="resetSearch">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 毕业申请列表 -->
    <el-card class="table-card">
      <template #header>
        <div class="card-header">
          <span>毕业申请列表</span>
          <div class="header-actions">
            <el-tag type="info">待审核: {{ pendingCount }}</el-tag>
            <el-tag type="success">已通过: {{ approvedCount }}</el-tag>
            <el-tag type="warning">已发证: {{ certifiedCount }}</el-tag>
            <el-tag type="danger">已驳回: {{ rejectedCount }}</el-tag>
          </div>
        </div>
      </template>

      <el-table :data="graduationList" stripe style="width: 100%" v-loading="loading">
        <el-table-column prop="studentId" label="考籍号" width="120" />
        <el-table-column prop="studentName" label="考生姓名" width="100" />
        <el-table-column prop="major" label="专业" width="150" />
        <el-table-column prop="batch" label="申请批次" width="120" />
        <el-table-column prop="applyDate" label="申请时间" width="120" />
        <el-table-column prop="courseCount" label="课程数" width="80" />
        <el-table-column prop="totalCredits" label="总学分" width="80" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getGraduationStatusType(scope.row.status)">
              {{ getGraduationStatusText(scope.row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="auditor" label="审核人" width="100" />
        <el-table-column prop="auditDate" label="审核时间" width="120" />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="viewDetail(scope.row)">查看</el-button>
            <el-button 
              size="small" 
              type="primary" 
              @click="auditGraduation(scope.row)"
              v-if="scope.row.status === 'pending'"
            >
              审核
            </el-button>
            <el-button 
              size="small" 
              type="success" 
              @click="issueCertificate(scope.row)"
              v-if="scope.row.status === 'final_approved'"
            >
              发证
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 毕业申请对话框 -->
    <el-dialog v-model="showApplyDialog" title="毕业申请" width="700px">
      <el-form :model="applyForm" :rules="applyRules" ref="applyFormRef" label-width="120px">
        <el-form-item label="考生信息">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-input v-model="applyForm.studentId" placeholder="请输入考籍号" />
            </el-col>
            <el-col :span="12">
              <el-button @click="searchStudent">查询考生</el-button>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="考生姓名" prop="studentName">
          <el-input v-model="applyForm.studentName" disabled />
        </el-form-item>
        <el-form-item label="报考专业" prop="major">
          <el-input v-model="applyForm.major" disabled />
        </el-form-item>
        <el-form-item label="申请批次" prop="batch">
          <el-select v-model="applyForm.batch" placeholder="请选择申请批次">
            <el-option label="2024年上半年" value="2024-1" />
            <el-option label="2024年下半年" value="2024-2" />
          </el-select>
        </el-form-item>
        <el-form-item label="毕业照片" prop="photo">
          <el-upload
            action="#"
            list-type="picture-card"
            :auto-upload="false"
            :on-change="handlePhotoChange"
            accept="image/*"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>
          <div class="upload-tip">请上传2寸蓝底免冠照片，用于毕业证书</div>
        </el-form-item>
        <el-form-item label="申请说明" prop="description">
          <el-input 
            v-model="applyForm.description" 
            type="textarea" 
            :rows="3"
            placeholder="请填写申请说明（可选）"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showApplyDialog = false">取消</el-button>
          <el-button type="primary" @click="submitGraduation">提交申请</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 资格审核对话框 -->
    <el-dialog v-model="showAuditDialog" title="毕业资格审核" width="600px">
      <el-form :model="auditForm" :rules="auditRules" ref="auditFormRef" label-width="120px">
        <el-form-item label="审核结果" prop="result">
          <el-radio-group v-model="auditForm.result">
            <el-radio label="approve">通过</el-radio>
            <el-radio label="reject">驳回</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="审核意见" prop="comment">
          <el-input 
            v-model="auditForm.comment" 
            type="textarea" 
            :rows="4"
            placeholder="请填写审核意见"
          />
        </el-form-item>
        <el-form-item label="审核级别" prop="level">
          <el-select v-model="auditForm.level" placeholder="请选择审核级别">
            <el-option label="市州审核" value="city" />
            <el-option label="省考试院终审" value="province" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showAuditDialog = false">取消</el-button>
          <el-button type="primary" @click="submitAudit">提交审核</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 证书管理对话框 -->
    <el-dialog v-model="showCertificateDialog" title="毕业证书管理" width="800px">
      <el-tabs v-model="certificateTab">
        <el-tab-pane label="证书制作" name="certificate-making">
          <el-table :data="certificateList" stripe style="width: 100%">
            <el-table-column prop="studentId" label="考籍号" width="120" />
            <el-table-column prop="studentName" label="考生姓名" width="100" />
            <el-table-column prop="major" label="专业" width="150" />
            <el-table-column prop="certificateNo" label="证书编号" width="150" />
            <el-table-column prop="issueDate" label="发证日期" width="120" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="scope">
                <el-tag :type="scope.row.status === 'issued' ? 'success' : 'warning'">
                  {{ scope.row.status === 'issued' ? '已发证' : '待发证' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button size="small" @click="downloadCertificate(scope.row)">下载</el-button>
                <el-button size="small" type="primary" @click="printCertificate(scope.row)">打印</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="证书统计" name="certificate-stats">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-card>
                <template #header>发证统计</template>
                <div class="chart-container">
                  <div class="chart-placeholder">发证统计图表</div>
                </div>
              </el-card>
            </el-col>
            <el-col :span="12">
              <el-card>
                <template #header>专业分布</template>
                <div class="chart-container">
                  <div class="chart-placeholder">专业分布图表</div>
                </div>
              </el-card>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  Plus, 
  Search, 
  Document, 
  Download
} from '@element-plus/icons-vue'

// 响应式数据
const loading = ref(false)
const showApplyDialog = ref(false)
const showAuditDialog = ref(false)
const showCertificateDialog = ref(false)
const certificateTab = ref('certificate-making')
const currentPage = ref(1)
const pageSize = ref(20)
const total = ref(0)
const pendingCount = ref(0)
const approvedCount = ref(0)
const certifiedCount = ref(0)
const rejectedCount = ref(0)

// 搜索表单
const searchForm = reactive({
  studentName: '',
  studentId: '',
  batch: '',
  status: ''
})

// 申请表单
const applyForm = reactive({
  studentId: '',
  studentName: '',
  major: '',
  batch: '',
  photo: [],
  description: ''
})

// 审核表单
const auditForm = reactive({
  result: '',
  comment: '',
  level: ''
})

// 表单验证规则
const applyRules = {
  batch: [
    { required: true, message: '请选择申请批次', trigger: 'change' }
  ]
}

const auditRules = {
  result: [
    { required: true, message: '请选择审核结果', trigger: 'change' }
  ],
  comment: [
    { required: true, message: '请填写审核意见', trigger: 'blur' }
  ],
  level: [
    { required: true, message: '请选择审核级别', trigger: 'change' }
  ]
}

// 毕业申请列表
const graduationList = ref([
  {
    studentId: '2024001',
    studentName: '张三',
    major: '计算机科学与技术',
    batch: '2024-1',
    applyDate: '2024-01-15',
    courseCount: 15,
    totalCredits: 75,
    status: 'pending',
    auditor: '',
    auditDate: ''
  },
  {
    studentId: '2024002',
    studentName: '李四',
    major: '汉语言文学',
    batch: '2024-1',
    applyDate: '2024-01-10',
    courseCount: 12,
    totalCredits: 60,
    status: 'final_approved',
    auditor: '王审核',
    auditDate: '2024-01-12'
  }
])

// 证书列表
const certificateList = ref([
  {
    studentId: '2024002',
    studentName: '李四',
    major: '汉语言文学',
    certificateNo: '2024001',
    issueDate: '2024-01-15',
    status: 'issued'
  }
])

// 获取毕业状态类型
const getGraduationStatusType = (status) => {
  const types = {
    pending: 'warning',
    first_approved: 'info',
    final_approved: 'success',
    certified: 'success',
    rejected: 'danger'
  }
  return types[status] || 'info'
}

// 获取毕业状态文本
const getGraduationStatusText = (status) => {
  const texts = {
    pending: '待审核',
    first_approved: '初审通过',
    final_approved: '终审通过',
    certified: '已发证',
    rejected: '已驳回'
  }
  return texts[status] || '未知'
}

// 搜索毕业申请
const searchGraduations = () => {
  loading.value = true
  setTimeout(() => {
    loading.value = false
    ElMessage.success('搜索完成')
  }, 1000)
}

// 重置搜索
const resetSearch = () => {
  Object.keys(searchForm).forEach(key => {
    searchForm[key] = ''
  })
}

// 查看详情
const viewDetail = (row) => {
  ElMessage.info(`查看毕业申请详情: ${row.studentName}`)
}

// 审核毕业申请
const auditGraduation = (row) => {
  showAuditDialog.value = true
  ElMessage.info(`审核毕业申请: ${row.studentName}`)
}

// 发证
const issueCertificate = (row) => {
  ElMessageBox.confirm(`确定要为考生 ${row.studentName} 发放毕业证书吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    ElMessage.success('毕业证书发放成功')
  })
}

// 导出毕业名单
const exportGraduationList = () => {
  ElMessage.success('毕业名单导出成功')
}

// 搜索考生
const searchStudent = () => {
  // 模拟查询考生信息
  applyForm.studentName = '张三'
  applyForm.major = '计算机科学与技术'
}

// 照片上传处理
const handlePhotoChange = (file) => {
  console.log('上传照片:', file)
}

// 提交毕业申请
const submitGraduation = () => {
  ElMessage.success('毕业申请提交成功')
  showApplyDialog.value = false
}

// 提交审核
const submitAudit = () => {
  ElMessage.success('审核提交成功')
  showAuditDialog.value = false
}

// 下载证书
const downloadCertificate = (row) => {
  ElMessage.success(`下载证书: ${row.studentName}`)
}

// 打印证书
const printCertificate = (row) => {
  ElMessage.success(`打印证书: ${row.studentName}`)
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
  searchGraduations()
}

const handleCurrentChange = (page) => {
  currentPage.value = page
  searchGraduations()
}

// 组件挂载时初始化数据
onMounted(() => {
  pendingCount.value = 25
  approvedCount.value = 150
  certifiedCount.value = 120
  rejectedCount.value = 5
  total.value = graduationList.value.length
})
</script>

<style scoped>
.graduation-management {
  padding: 20px;
}

.operation-bar {
  margin-bottom: 20px;
}

.search-card {
  margin-bottom: 20px;
}

.search-form {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.table-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

.chart-container {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.chart-placeholder {
  color: #909399;
  font-size: 14px;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-form {
    flex-direction: column;
  }
  
  .card-header {
    flex-direction: column;
    gap: 10px;
  }
  
  .header-actions {
    justify-content: center;
  }
}
</style> 