<template>
  <div class="student-archive">
    <!-- 功能操作栏 -->
    <div class="operation-bar">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-button type="primary" @click="showCreateDialog = true">
            <el-icon><Plus /></el-icon>
            考籍建档
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="success" @click="showBatchImportDialog = true">
            <el-icon><Upload /></el-icon>
            批量导入
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="warning" @click="exportData">
            <el-icon><Download /></el-icon>
            导出数据
          </el-button>
        </el-col>
        <el-col :span="6">
          <el-button type="info" @click="showStatisticsDialog = true">
            <el-icon><Search /></el-icon>
            统计分析
          </el-button>
        </el-col>
      </el-row>
    </div>

    <!-- 搜索条件 -->
    <el-card class="search-card">
      <el-form :inline="true" :model="searchForm" class="search-form">
        <el-form-item label="考籍号">
          <el-input v-model="searchForm.studentId" placeholder="请输入考籍号" clearable />
        </el-form-item>
        <el-form-item label="身份证号">
          <el-input v-model="searchForm.idCard" placeholder="请输入身份证号" clearable />
        </el-form-item>
        <el-form-item label="姓名">
          <el-input v-model="searchForm.name" placeholder="请输入姓名" clearable />
        </el-form-item>
        <el-form-item label="专业">
          <el-select v-model="searchForm.major" placeholder="请选择专业" clearable>
            <el-option label="计算机科学与技术" value="计算机科学与技术" />
            <el-option label="汉语言文学" value="汉语言文学" />
            <el-option label="工商管理" value="工商管理" />
            <el-option label="会计学" value="会计学" />
          </el-select>
        </el-form-item>
        <el-form-item label="考籍状态">
          <el-select v-model="searchForm.status" placeholder="请选择状态" clearable>
            <el-option label="正常" value="normal" />
            <el-option label="冻结" value="frozen" />
            <el-option label="注销" value="cancelled" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="searchStudents">查询</el-button>
          <el-button @click="resetSearch">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 考生列表 -->
    <el-card class="table-card">
      <template #header>
        <div class="card-header">
          <span>考生考籍档案列表</span>
          <div class="header-actions">
            <el-tag type="success">总数: {{ totalCount }}</el-tag>
            <el-tag type="warning">正常: {{ normalCount }}</el-tag>
            <el-tag type="danger">冻结: {{ frozenCount }}</el-tag>
          </div>
        </div>
      </template>

      <el-table :data="studentList" stripe style="width: 100%" v-loading="loading">
        <el-table-column prop="studentId" label="考籍号" width="120" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="idCard" label="身份证号" width="180" />
        <el-table-column prop="major" label="专业" width="150" />
        <el-table-column prop="registerDate" label="注册时间" width="120" />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ getStatusText(scope.row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="phone" label="联系电话" width="120" />
        <el-table-column prop="address" label="住址" min-width="200" show-overflow-tooltip />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="viewStudent(scope.row)">查看</el-button>
            <el-button size="small" type="primary" @click="editStudent(scope.row)">编辑</el-button>
            <el-button size="small" type="warning" @click="viewScores(scope.row)">成绩</el-button>
            <el-dropdown @command="handleCommand" trigger="click">
              <el-button size="small" type="info">
                更多<el-icon class="el-icon--right"><arrow-down /></el-icon>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item :command="{ action: 'freeze', row: scope.row }">
                    冻结考籍
                  </el-dropdown-item>
                  <el-dropdown-item :command="{ action: 'unfreeze', row: scope.row }">
                    解冻考籍
                  </el-dropdown-item>
                  <el-dropdown-item :command="{ action: 'cancel', row: scope.row }">
                    注销考籍
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 考籍建档对话框 -->
    <el-dialog v-model="showCreateDialog" title="考籍建档" width="600px">
      <el-form :model="createForm" :rules="createRules" ref="createFormRef" label-width="100px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="createForm.name" placeholder="请输入真实姓名" />
        </el-form-item>
        <el-form-item label="身份证号" prop="idCard">
          <el-input v-model="createForm.idCard" placeholder="请输入身份证号" />
        </el-form-item>
        <el-form-item label="报考专业" prop="major">
          <el-select v-model="createForm.major" placeholder="请选择专业">
            <el-option label="计算机科学与技术" value="计算机科学与技术" />
            <el-option label="汉语言文学" value="汉语言文学" />
            <el-option label="工商管理" value="工商管理" />
            <el-option label="会计学" value="会计学" />
          </el-select>
        </el-form-item>
        <el-form-item label="联系电话" prop="phone">
          <el-input v-model="createForm.phone" placeholder="请输入联系电话" />
        </el-form-item>
        <el-form-item label="住址" prop="address">
          <el-input v-model="createForm.address" type="textarea" placeholder="请输入详细住址" />
        </el-form-item>
        <el-form-item label="注册时间" prop="registerDate">
          <el-date-picker v-model="createForm.registerDate" type="date" placeholder="选择注册时间" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showCreateDialog = false">取消</el-button>
          <el-button type="primary" @click="createStudent">确定</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 批量导入对话框 -->
    <el-dialog v-model="showBatchImportDialog" title="批量导入考生" width="500px">
      <el-upload
        class="upload-demo"
        drag
        action="#"
        :auto-upload="false"
        :on-change="handleFileChange"
        accept=".xlsx,.xls"
      >
        <el-icon class="el-icon--upload"><upload-filled /></el-icon>
        <div class="el-upload__text">
          将文件拖到此处，或<em>点击上传</em>
        </div>
        <template #tip>
          <div class="el-upload__tip">
            只能上传 xlsx/xls 文件，且不超过 10MB
          </div>
        </template>
      </el-upload>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showBatchImportDialog = false">取消</el-button>
          <el-button type="primary" @click="importStudents">开始导入</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 统计分析对话框 -->
    <el-dialog v-model="showStatisticsDialog" title="统计分析" width="800px">
      <el-row :gutter="20">
        <el-col :span="12">
          <el-card>
            <template #header>专业分布</template>
            <div class="chart-container">
              <!-- 这里可以集成图表库如 ECharts -->
              <div class="chart-placeholder">专业分布图表</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="12">
          <el-card>
            <template #header>性别比例</template>
            <div class="chart-container">
              <div class="chart-placeholder">性别比例图表</div>
            </div>
          </el-card>
        </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-top: 20px;">
        <el-col :span="24">
          <el-card>
            <template #header>年龄分布</template>
            <div class="chart-container">
              <div class="chart-placeholder">年龄分布图表</div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  Plus, 
  Upload, 
  Download, 
  Search, 
  Edit, 
  Delete,
  ArrowDown,
  UploadFilled
} from '@element-plus/icons-vue'

// 响应式数据
const loading = ref(false)
const showCreateDialog = ref(false)
const showBatchImportDialog = ref(false)
const showStatisticsDialog = ref(false)
const currentPage = ref(1)
const pageSize = ref(20)
const total = ref(0)
const totalCount = ref(0)
const normalCount = ref(0)
const frozenCount = ref(0)

// 搜索表单
const searchForm = reactive({
  studentId: '',
  idCard: '',
  name: '',
  major: '',
  status: ''
})

// 创建表单
const createForm = reactive({
  name: '',
  idCard: '',
  major: '',
  phone: '',
  address: '',
  registerDate: ''
})

// 表单验证规则
const createRules = {
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' },
    { min: 2, max: 10, message: '姓名长度在 2 到 10 个字符', trigger: 'blur' }
  ],
  idCard: [
    { required: true, message: '请输入身份证号', trigger: 'blur' },
    { pattern: /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/, message: '身份证号格式不正确', trigger: 'blur' }
  ],
  major: [
    { required: true, message: '请选择专业', trigger: 'change' }
  ],
  phone: [
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
  ]
}

// 模拟数据
const studentList = ref([
  {
    studentId: '2024001',
    name: '张三',
    idCard: '110101199001011234',
    major: '计算机科学与技术',
    registerDate: '2024-01-15',
    status: 'normal',
    phone: '13800138001',
    address: '北京市朝阳区xxx街道xxx号'
  },
  {
    studentId: '2024002',
    name: '李四',
    idCard: '110101199002022345',
    major: '汉语言文学',
    registerDate: '2024-01-20',
    status: 'frozen',
    phone: '13800138002',
    address: '北京市海淀区xxx街道xxx号'
  }
])

// 获取状态类型
const getStatusType = (status) => {
  const types = {
    normal: 'success',
    frozen: 'warning',
    cancelled: 'danger'
  }
  return types[status] || 'info'
}

// 获取状态文本
const getStatusText = (status) => {
  const texts = {
    normal: '正常',
    frozen: '冻结',
    cancelled: '注销'
  }
  return texts[status] || '未知'
}

// 搜索考生
const searchStudents = () => {
  loading.value = true
  // 模拟API调用
  setTimeout(() => {
    loading.value = false
    ElMessage.success('搜索完成')
  }, 1000)
}

// 重置搜索
const resetSearch = () => {
  Object.keys(searchForm).forEach(key => {
    searchForm[key] = ''
  })
}

// 创建考生
const createStudent = () => {
  ElMessage.success('考籍建档成功')
  showCreateDialog.value = false
}

// 查看考生详情
const viewStudent = (row) => {
  ElMessage.info(`查看考生: ${row.name}`)
}

// 编辑考生信息
const editStudent = (row) => {
  ElMessage.info(`编辑考生: ${row.name}`)
}

// 查看成绩
const viewScores = (row) => {
  ElMessage.info(`查看成绩: ${row.name}`)
}

// 处理下拉菜单命令
const handleCommand = ({ action, row }) => {
  switch (action) {
    case 'freeze':
      ElMessageBox.confirm(`确定要冻结考生 ${row.name} 的考籍吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        ElMessage.success('考籍已冻结')
      })
      break
    case 'unfreeze':
      ElMessage.success('考籍已解冻')
      break
    case 'cancel':
      ElMessageBox.confirm(`确定要注销考生 ${row.name} 的考籍吗？此操作不可恢复！`, '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }).then(() => {
        ElMessage.success('考籍已注销')
      })
      break
  }
}

// 导出数据
const exportData = () => {
  ElMessage.success('数据导出成功')
}

// 文件上传处理
const handleFileChange = (file) => {
  console.log('选择的文件:', file)
}

// 批量导入
const importStudents = () => {
  ElMessage.success('批量导入成功')
  showBatchImportDialog.value = false
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
  searchStudents()
}

const handleCurrentChange = (page) => {
  currentPage.value = page
  searchStudents()
}

// 组件挂载时初始化数据
onMounted(() => {
  totalCount.value = 1250
  normalCount.value = 1180
  frozenCount.value = 70
  total.value = studentList.value.length
})
</script>

<style scoped>
.student-archive {
  padding: 20px;
}

.operation-bar {
  margin-bottom: 20px;
}

.search-card {
  margin-bottom: 20px;
}

.search-form {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.table-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

.chart-container {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.chart-placeholder {
  color: #909399;
  font-size: 14px;
}

.upload-demo {
  text-align: center;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-form {
    flex-direction: column;
  }
  
  .card-header {
    flex-direction: column;
    gap: 10px;
  }
  
  .header-actions {
    justify-content: center;
  }
}
</style> 