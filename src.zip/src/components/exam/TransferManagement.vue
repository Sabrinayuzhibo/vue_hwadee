<template>
  <div class="transfer-management">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="考籍转入" name="transfer-in">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>转入申请列表</span>
              <el-button type="primary" @click="showInDialog = true">
                <el-icon><Plus /></el-icon>
                接收转入
              </el-button>
            </div>
          </template>
          
          <el-table :data="transferInList" stripe style="width: 100%">
            <el-table-column prop="studentId" label="考籍号" width="120" />
            <el-table-column prop="studentName" label="考生姓名" width="100" />
            <el-table-column prop="fromProvince" label="来源省份" width="100" />
            <el-table-column prop="major" label="专业" width="150" />
            <el-table-column prop="courseCount" label="课程数" width="80" />
            <el-table-column prop="applyDate" label="申请时间" width="120" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="scope">
                <el-tag :type="getTransferStatusType(scope.row.status)">
                  {{ getTransferStatusText(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button size="small" @click="auditTransferIn(scope.row)">审核</el-button>
                <el-button size="small" type="warning" @click="viewTransferDetail(scope.row)">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="考籍转出" name="transfer-out">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>转出申请列表</span>
              <el-button type="success" @click="showOutDialog = true">
                <el-icon><Plus /></el-icon>
                申请转出
              </el-button>
            </div>
          </template>
          
          <el-table :data="transferOutList" stripe style="width: 100%">
            <el-table-column prop="studentId" label="考籍号" width="120" />
            <el-table-column prop="studentName" label="考生姓名" width="100" />
            <el-table-column prop="toProvince" label="目标省份" width="100" />
            <el-table-column prop="major" label="专业" width="150" />
            <el-table-column prop="courseCount" label="课程数" width="80" />
            <el-table-column prop="applyDate" label="申请时间" width="120" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="scope">
                <el-tag :type="getTransferStatusType(scope.row.status)">
                  {{ getTransferStatusText(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="150">
              <template #default="scope">
                <el-button size="small" @click="viewTransferDetail(scope.row)">详情</el-button>
                <el-button size="small" type="warning" @click="cancelTransfer(scope.row)">取消</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <!-- 转入申请对话框 -->
    <el-dialog v-model="showInDialog" title="接收转入申请" width="600px">
      <el-form :model="transferInForm" label-width="120px">
        <el-form-item label="来源省份">
          <el-select v-model="transferInForm.fromProvince" placeholder="请选择来源省份">
            <el-option label="北京市" value="北京" />
            <el-option label="上海市" value="上海" />
            <el-option label="广东省" value="广东" />
          </el-select>
        </el-form-item>
        <el-form-item label="考生姓名">
          <el-input v-model="transferInForm.studentName" placeholder="请输入考生姓名" />
        </el-form-item>
        <el-form-item label="身份证号">
          <el-input v-model="transferInForm.idCard" placeholder="请输入身份证号" />
        </el-form-item>
        <el-form-item label="转考原因">
          <el-input v-model="transferInForm.reason" type="textarea" placeholder="请输入转考原因" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showInDialog = false">取消</el-button>
          <el-button type="primary" @click="submitTransferIn">接收</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 转出申请对话框 -->
    <el-dialog v-model="showOutDialog" title="申请转出" width="600px">
      <el-form :model="transferOutForm" label-width="120px">
        <el-form-item label="考籍号">
          <el-input v-model="transferOutForm.studentId" placeholder="请输入考籍号" />
        </el-form-item>
        <el-form-item label="目标省份">
          <el-select v-model="transferOutForm.toProvince" placeholder="请选择目标省份">
            <el-option label="北京市" value="北京" />
            <el-option label="上海市" value="上海" />
            <el-option label="广东省" value="广东" />
          </el-select>
        </el-form-item>
        <el-form-item label="转考原因">
          <el-input v-model="transferOutForm.reason" type="textarea" placeholder="请输入转考原因" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showOutDialog = false">取消</el-button>
          <el-button type="primary" @click="submitTransferOut">申请</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'

const activeTab = ref('transfer-in')
const showInDialog = ref(false)
const showOutDialog = ref(false)

const transferInList = ref([
  {
    studentId: 'BJ2024001',
    studentName: '王五',
    fromProvince: '北京',
    major: '计算机科学与技术',
    courseCount: 8,
    applyDate: '2024-01-15',
    status: 'pending'
  }
])

const transferOutList = ref([
  {
    studentId: '2024001',
    studentName: '张三',
    toProvince: '上海',
    major: '计算机科学与技术',
    courseCount: 10,
    applyDate: '2024-01-10',
    status: 'approved'
  }
])

const transferInForm = reactive({
  fromProvince: '',
  studentName: '',
  idCard: '',
  reason: ''
})

const transferOutForm = reactive({
  studentId: '',
  toProvince: '',
  reason: ''
})

const getTransferStatusType = (status) => {
  const types = {
    pending: 'warning',
    approved: 'success',
    rejected: 'danger',
    completed: 'info'
  }
  return types[status] || 'info'
}

const getTransferStatusText = (status) => {
  const texts = {
    pending: '待审核',
    approved: '已通过',
    rejected: '已驳回',
    completed: '已完成'
  }
  return texts[status] || '未知'
}

const auditTransferIn = (row) => {
  ElMessage.info(`审核转入申请: ${row.studentName}`)
}

const viewTransferDetail = (row) => {
  ElMessage.info(`查看转考详情: ${row.studentName}`)
}

const cancelTransfer = (row) => {
  ElMessage.success(`取消转考申请: ${row.studentName}`)
}

const submitTransferIn = () => {
  ElMessage.success('转入申请接收成功')
  showInDialog.value = false
}

const submitTransferOut = () => {
  ElMessage.success('转出申请提交成功')
  showOutDialog.value = false
}
</script>

<style scoped>
.transfer-management {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 