import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import HomeView from '../views/HomeView.vue'
import RegisterView from '../views/RegisterView.vue'
import UserView from '../views/UserView.vue'
import ExamManagementView from '../views/ExamManagementView.vue'
import TestView from '../views/TestView.vue'


const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
      meta: { requiresAuth: false, title: '首页' }
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView,
      meta: { requiresAuth: false, title: '登录' }
    },
    {
      path: '/register',
      name: 'register',
      component: RegisterView,
      meta: { requiresAuth: false, title: '注册' }
    },
    {
      path: '/user',
      name: 'user',
      component: UserView,
      meta: { requiresAuth: true, title: '用户中心' }
    },
    {
      path: '/exam-management',
      name: 'exam-management',
      component: ExamManagementView,

    },
    {
      path: '/test',
      name: 'test',
      component: TestView,
      meta: { requiresAuth: false, title: '测试页面' }
    }
  ],
})

// 路由守卫 - 检查用户是否已登录
router.beforeEach((to, from, next) => {
  const isAuthenticated = !!localStorage.getItem('token')
  
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!isAuthenticated) {
      next('/login')
    } else {
      next()
    }
  } else {
    if (to.path === '/login' && isAuthenticated) {
      next('/')
    } else {
      next()
    }
  }
})

export default router
