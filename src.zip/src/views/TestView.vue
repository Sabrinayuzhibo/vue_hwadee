<template>
  <div class="test-page">
    <h1>测试页面</h1>
    <p>如果你能看到这个页面，说明基本路由和组件加载正常。</p>
    
    <el-button type="primary" @click="testMessage">测试消息</el-button>
    <el-button type="success" @click="testDialog">测试对话框</el-button>
    
    <div style="margin-top: 20px;">
      <el-card>
        <template #header>
          <span>Element Plus 组件测试</span>
        </template>
        <el-table :data="tableData" style="width: 100%">
          <el-table-column prop="name" label="姓名" />
          <el-table-column prop="age" label="年龄" />
          <el-table-column prop="city" label="城市" />
        </el-table>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const tableData = ref([
  { name: '张三', age: 25, city: '北京' },
  { name: '李四', age: 30, city: '上海' },
  { name: '王五', age: 28, city: '广州' }
])

const testMessage = () => {
  ElMessage.success('Element Plus 消息组件正常工作！')
}

const testDialog = () => {
  ElMessageBox.confirm('这是一个测试对话框', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'info'
  }).then(() => {
    ElMessage.success('你点击了确定')
  })
}
</script>

<style scoped>
.test-page {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}

h1 {
  color: #409eff;
  margin-bottom: 20px;
}
</style> 